let is_none = function
  | None -> true
  | Some _v -> false
