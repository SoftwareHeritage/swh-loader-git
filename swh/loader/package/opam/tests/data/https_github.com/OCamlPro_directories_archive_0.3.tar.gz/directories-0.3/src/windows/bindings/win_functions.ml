
include Win_functions_functor.Apply(Win_functions_stubs)
