## 0.2 - 2020-11-09

- fix opam file

## 0.1 - 2020-11-08

First release
