from distutils.core import setup

setup(
    name = '0805nexter',
    version = '1.1.0',
    py_modules = ['0805nexter'],
    author = 'hgtkpython',
    author_email = '2868989685@qq.com',
    url = 'http://www.hp.com',
    description = 'a simple printer of nested lest',
    )
